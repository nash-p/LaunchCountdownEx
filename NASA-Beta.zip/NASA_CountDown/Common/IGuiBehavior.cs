﻿namespace NASA_CountDown.Common
{
    public interface IGuiBehavior
    {
        void Draw();
    }
}