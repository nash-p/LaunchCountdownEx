﻿using UnityEngine;

namespace NASA_CountDown.Helpers
{
    public class DummyComponent: MonoBehaviour
    {
         
    }
}